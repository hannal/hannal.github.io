# -*- coding: utf-8 -*-
from django.http import HttpResponse
from hannal.blog.models import Entries, Categories, TagModel, Comments
from django.template import Context, loader
import md5
from django.utils import simplejson

def index(request, page=1):
    per_page = 5
    start_pos = (page - 1) * per_page
    end_pos = start_pos + per_page
    
    page_title = '블로그 글 목록 화면'
    
    entries = Entries.objects.select_related().all().order_by('-created')[start_pos:end_pos]

    tpl = loader.get_template('list.html')
    ctx = Context({
        'page_title':page_title,
        'entries':entries,
        'current_page':page
    })
    return HttpResponse(tpl.render(ctx))


def add_post(request):
    # 글 제목 처리
    if request.POST.has_key('title') == False:
        return HttpResponse('글 제목을 입력해야 한다우.')
    else:
        if len(request.POST['title']) == 0:
            return HttpResponse('글 제목엔 적어도 한 글자는 넣자!')
        else:
            entry_title = request.POST['title']

    # 글 본문 처리
    if request.POST.has_key('content') == False:
        return HttpResponse('글 본문을 입력해야 한다우.')
    else:
        if len(request.POST['content']) == 0:
            return HttpResponse('글 본문엔 적어도 한 글자는 넣자!')
        else:
            entry_content = request.POST['content']

    # 글 갈래 처리
    if request.POST.has_key('category') == False:
        return HttpResponse('글 갈래를 골라야 한다우.')
    else:
        try:
            entry_category = Categories.objects.get(id=request.POST['category'])
        except:
            return HttpResponse('이상한 글 갈래구려')

    # 글 꼬리표 처리
    if request.POST.has_key('tags') == True:
        tags = map(lambda str: str.strip(), unicode(request.POST['tags']).split(','))
        tag_list = map(lambda tag: TagModel.objects.get_or_create(Title=tag)[0], tags)
    else:
        tag_list = []
    
    # 꼬리표 저장을 위해 임시 저장
    new_entry = Entries(Title=entry_title, Content=entry_content, Category=entry_category)
    try:
        new_entry.save()
    except:
        return HttpResponse('글을 써넣다가 오류가 발생했습니다.')
    
    # 꼬리표 추가
    for tag in tag_list:
        new_entry.Tags.add(tag)
        
    # 최종 저장.
    if len(tag_list) > 0:
        try:
            new_entry.save()
        except:
            return HttpResponse('글을 써넣다가 오류가 발생했습니다.')

    return HttpResponse('%s번 글을 제대로 써넣었습니다.' % new_entry.id)



def add_comment(request):    
    # 글쓴이 이름 처리
    if request.POST.has_key('name') == False:
        return HttpResponse('글쓴이 이름을 입력해야 한다우.')
    else:
        if len(request.POST['name']) == 0:
            return HttpResponse('글쓴이 이름을 입력해야 한다우.')
        else:
            cmt_name = request.POST['name']

    # 비밀번호
    if request.POST.has_key('password') == False:
        return HttpResponse('비밀번호를 입력해야 한다우.')
    else:
        if len(request.POST['password']) == 0:
            return HttpResponse('비밀번호를 입력해야 한다우.')
        else:
            cmt_password = md5.md5(request.POST['password']).hexdigest()

    # 댓글 본문 처리
    if request.POST.has_key('content') == False:
        return HttpResponse('댓글 내용을 입력해야 한다우.')
    else:
        if len(request.POST['content']) == 0:
            return HttpResponse('댓글 내용을 입력해야 한다우.')
        else:
            cmt_content = request.POST['content']

    # 댓글 달 글 확인
    if request.POST.has_key('entry_id') == False:
        return HttpResponse('댓글 달 글을 지정해야 한다우.')
    else:
        try:
            entry = Entries.objects.get(id=request.POST['entry_id'])
        except:
            return HttpResponse('그런 글은 없지롱')

    try:
        new_cmt = Comments(Name=cmt_name, Password=cmt_password, Content=cmt_content, Entry=entry)
        new_cmt.save()
        entry.Comments += 1
        entry.save()
        
        if is_ajax(request):
            return_data = {
                'entry_id':entry.id,
                'msg':get_comments(request, entry.id, True)
            }
            return HttpResponse(simplejson.dumps(return_data))
        else:
            return HttpResponse('댓글 잘 매달았다, 얼쑤.')
    except:
        return HttpResponse('제대로 저장하지 못했습니다.')
    return HttpResponse('문제가 생겨 저장하지 못했습니다.')


def write_form(request):
    page_title = '블로그 글 쓰기 화면'
    
    categories = Categories.objects.all()
    tpl = loader.get_template('write.html')
    ctx = Context({
        'page_title':page_title,
        'categories':categories
    })
    return HttpResponse(tpl.render(ctx))


def read(request, entry_id=None):
    page_title = '블로그 글 읽기 화면'
    
    try:
        current_entry = Entries.objects.get(id=int(entry_id))
    except:
        return HttpResponse('그런 글이 존재하지 않습니다.')

    try:
        prev_entry = current_entry.get_previous_by_created()
    except:
        prev_entry = None
    
    try:
        next_entry = current_entry.get_next_by_created()
    except:
        next_entry = None

    comments = Comments.objects.filter(Entry=current_entry).order_by('created')
    
    tpl = loader.get_template('read.html')
    ctx = Context({
        'page_title':page_title,
        'current_entry':current_entry,
        'prev_entry':prev_entry,
        'next_entry':next_entry,
        'with_layout':False,
        'comments':comments
    })
    return HttpResponse(tpl.render(ctx))


def get_comments(request, entry_id=None, is_inner=False):    
    try:
        current_entry = Entries.objects.get(id=int(entry_id))
    except:
        return HttpResponse('그런 글이 존재하지 않습니다.')
        
    comments = Comments.objects.filter(Entry=current_entry).order_by('created')

    if is_ajax(request):
        with_layout = False
    else:        
        with_layout = True
    
    tpl = loader.get_template('comments.html')
    ctx = Context({
    	'current_entry':current_entry,
        'comments':comments,
        'with_layout':with_layout
    })
    if is_inner == True:
        return tpl.render(ctx)
    else:
        return HttpResponse(tpl.render(ctx))



def is_ajax(request):
    if dir(request).count('is_ajax') > 0:
        return request.is_ajax()
    else:
        return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
