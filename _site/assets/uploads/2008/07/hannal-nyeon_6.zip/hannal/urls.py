import os
ROOT_PATH = os.path.dirname(__file__)

from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    (r'^blog/$', 'hannal.blog.views.index'),
    (r'^blog/page/(?P<page>\d+)/$', 'hannal.blog.views.index'),
    (r'^blog/entry/(?P<entry_id>\d+)/$', 'hannal.blog.views.read'),
    (r'^blog/write/$', 'hannal.blog.views.write_form'),
    (r'^blog/add/post/$', 'hannal.blog.views.add_post'),
    (r'^blog/add/comment/$', 'hannal.blog.views.add_comment'),
    (r'^blog/get_comments/(?P<entry_id>\d+)/$', 'hannal.blog.views.get_comments'),

     (r'^admin/', include('django.contrib.admin.urls')),
)

if settings.DEBUG:
    urlpatterns += patterns('',
        (r'^media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': ROOT_PATH+'/media'}),
    )
