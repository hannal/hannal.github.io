# -*- coding: utf-8 -*-
from django.http import HttpResponse
from hannal.blog.models import Entries

def index(request, page=1):
    per_page = 5
    start_pos = (page - 1) * per_page
    end_pos = start_pos + per_page
    
    page_title = '블로그 글 목록 화면'
    
    entries = Entries.objects.all().order_by('-created')[start_pos:end_pos]

    return HttpResponse('안녕, 여러분. [%s] 글은 첫 번째 글이야.' % entries[0].Title.encode('utf-8'))



def read(request, entry_id=None):
    page_title = '블로그 글 목록 화면'
    
    current_entry = Entries.objects.get(id=int(entry_id))
    prev_entry = current_entry.get_previous_by_created()
    next_entry = current_entry.get_next_by_created()
    
    return HttpResponse('안녕, 여러분. [%d]번 글은 [%s]이야.' % (current_entry.id, current_entry.Title.encode('utf-8')))
