from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^blog/$', 'hannal.blog.views.index'),
    (r'^blog/page/(?P<page>\d+)/$', 'hannal.blog.views.index'),
    (r'^blog/entry/(?P<entry_id>\d+)/$', 'hannal.blog.views.read'),

     (r'^admin/', include('django.contrib.admin.urls')),
)
